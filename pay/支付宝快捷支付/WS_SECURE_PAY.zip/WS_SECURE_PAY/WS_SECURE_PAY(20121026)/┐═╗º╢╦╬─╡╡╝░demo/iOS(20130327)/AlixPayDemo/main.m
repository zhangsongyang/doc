//
//  main.m
//  AlixPayDemo
//
//  Created by Jing Wen on 8/3/11.
//  Copyright 2011 alipay.com. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, @"AlixPayDemoAppDelegate");
    [pool release];
    return retVal;
}
