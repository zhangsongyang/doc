package com.alipay.android.appDemo4;

public class Constant
{
	public final static String server_url = "https://msp.alipay.com/x.htm";
}