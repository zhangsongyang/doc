/** Automatically generated file. DO NOT MODIFY */
package com.alipay.android.appDemo4;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}